/* ══════════════════════════════════════════════════════════════
   작업창 — 이 확장의 두뇌

   페이지들은 시키는 일만 한다. 판단과 상태는 전부 여기 있다.
   ══════════════════════════════════════════════════════════════ */
(() => {
  "use strict";

  /* ─────────── 상태 ─────────── */
  const S = {
    platform: "chatgpt",
    saleMode: "auto",  // 물건 종류 — auto(자동 판별) · listing(일반 매물) · auction(경매·공매)
    kind: "news",      // 기사 스타일 — GW_KIND
    length: "normal",  // 분량 — GW_LENGTH
    imageStyle: "news",
    customStyle: "",
    imageRequest: "",
    gongsilTabId: null,
    aiTabId: null,
    origin: "https://gongsilnews.com",
    vacancy: null,
    article: null,   // { title, subtitles[], body, keywords[] }
    writing: false,  // AI 에 기사를 보내고 아직 가져오지 않았다 — 작성 중 안내를 띄운다
    media: [],       // [{ kind:'photo'|'proof'|'map'|'roadview'|'ai', url, caption, isCover }]
  };

  const $ = (id) => document.getElementById(id);

  const el = {
    status: $("statusPill"),
    tabWork: $("tabWork"), tabDraft: $("tabDraft"), draftBadge: $("draftBadge"),
    viewWork: $("viewWork"), viewDraft: $("viewDraft"),
    btnGoGongsil: $("btnGoGongsil"), btnGrab: $("btnGrab"),
    vacancyCard: $("vacancyCard"), vacancyKind: $("vacancyKind"), vacancyName: $("vacancyName"), vacancyFields: $("vacancyFields"),
    btnOpenAi: $("btnOpenAi"), btnSubmit: $("btnSubmit"), btnPullDraft: $("btnPullDraft"),
    draftEmpty: $("draftEmpty"), draftBody: $("draftBody"), draftActions: $("draftActions"),
    pvDate: $("pvDate"), pvTitle: $("pvTitle"), pvSubtitle: $("pvSubtitle"),
    pvCover: $("pvCover"), pvContent: $("pvContent"), pvKeywords: $("pvKeywords"),
    reviseInput: $("reviseInput"), btnRevise: $("btnRevise"), btnPullRevised: $("btnPullRevised"),
    imageCustomStyle: $("imageCustomStyle"),
    imageRequest: $("imageRequest"),
    btnMakeImage: $("btnMakeImage"), btnChangeImage: $("btnChangeImage"), fileImage: $("fileImage"),
    btnSendGongsil: $("btnSendGongsil"),
    articleWriting: $("articleWriting"), articleFail: $("articleFail"),
    toastHost: $("toastHost"),
  };

  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  /* ═════════════ 알림 ═════════════ */
  function toast(message, kind = "info", ms = 4000) {
    const box = document.createElement("div");
    box.className = `toast ${kind}`;
    box.textContent = message;
    el.toastHost.appendChild(box);
    requestAnimationFrame(() => box.classList.add("in"));
    setTimeout(() => {
      box.classList.remove("in");
      setTimeout(() => box.remove(), 260);
    }, ms);
  }

  function status(text, kind = "") {
    el.status.textContent = text;
    el.status.className = "status-pill" + (kind ? " " + kind : "");
  }

  /* 누르는 동안 잠가 둔다 — 두 번 눌러 생기는 사고를 막는다.
     opts.cover   : 그 글 영역에 반투명 흰 막과 같은 멘트를 띄운다
     opts.failTitle: 실패하면 빨간 안내 카드를 남긴다 (opts.fail 칸, 없으면 cover 맨 위)
     opts.retry   : 카드의 [다시 가져오기]가 누를 버튼 */
  async function guard(btn, busyText, fn, opts = {}) {
    const keep = btn.innerHTML;
    const failBox = opts.fail || opts.cover;
    btn.disabled = true;
    GWBusy.clearFail(failBox);
    GWBusy.start(btn, busyText, opts.cover);
    status(busyText, "busy");
    try {
      await fn();
    } catch (e) {
      console.error("[공실뉴스 작업창]", e);
      toast(e.message || String(e), "bad", 7000);
      status("문제 발생", "bad");
      if (opts.failTitle) GWBusy.fail(failBox, opts.failTitle, e.message || String(e), opts.retry);
    } finally {
      GWBusy.stop(btn);
      btn.disabled = false;
      btn.innerHTML = keep;
      refreshButtons();
    }
  }

  /* ═════════════ 탭 다루기 ═════════════ */
  const GONGSIL_URLS = [
    "https://gongsilnews.com/gongsil*",
    "https://*.gongsilnews.com/gongsil*",
    "http://localhost/gongsil*",
  ];

  async function findTab(patterns) {
    const tabs = await chrome.tabs.query({ url: patterns });
    return tabs.length ? tabs[0] : null;
  }

  async function askTab(tabId, msg) {
    if (!tabId) throw new Error("대상 탭이 없습니다.");
    try {
      const res = await chrome.tabs.sendMessage(tabId, msg);
      if (res === undefined) throw new Error("탭이 응답하지 않았습니다.");
      return res;
    } catch (e) {
      throw new Error(
        "탭과 연결되지 않았습니다. 그 탭을 한 번 새로고침(F5)한 뒤 다시 눌러 주세요. (" + e.message + ")"
      );
    }
  }

  /* ═════════════ ① 공실열람 페이지 이동 ═════════════ */
  el.btnGoGongsil.addEventListener("click", () =>
    guard(el.btnGoGongsil, "공실열람 여는 중", async () => {
      const found = await findTab(GONGSIL_URLS);

      if (found) {
        await chrome.tabs.update(found.id, { active: true });
        await chrome.windows.update(found.windowId, { focused: true });
        S.gongsilTabId = found.id;
        S.origin = new URL(found.url).origin;
        toast("이미 열려 있는 공실열람 탭으로 이동했습니다.", "info");
      } else {
        const [active] = await chrome.tabs.query({ active: true, currentWindow: true });
        const url = "https://gongsilnews.com/gongsil";
        const tab = active
          ? await chrome.tabs.update(active.id, { url })
          : await chrome.tabs.create({ url });
        S.gongsilTabId = tab.id;
        S.origin = "https://gongsilnews.com";
        toast("공실열람으로 이동했습니다. 매물이나 [경매/공매] 물건을 하나 펼쳐 주세요.", "info");
      }

      status("공실열람 열림", "ok");
      save();
    })
  );

  /* ═════════════ ② 물건 가져오기 (+ 사진 4종) ═════════════ */
  el.btnGrab.addEventListener("click", () =>
    guard(el.btnGrab, "물건 가져오는 중", async () => {
      let tab = S.gongsilTabId ? await chrome.tabs.get(S.gongsilTabId).catch(() => null) : null;
      if (!tab || !/\/gongsil/.test(tab.url || "")) tab = await findTab(GONGSIL_URLS);

      if (!tab) throw new Error("공실열람 탭이 없습니다. 먼저 [공실열람 페이지 이동] 을 눌러 주세요.");

      S.gongsilTabId = tab.id;
      S.origin = new URL(tab.url).origin;

      const res = await askTab(tab.id, { type: "GW_GET_VACANCY" });
      if (!res.ok) throw new Error(res.reason || "물건을 읽지 못했습니다.");

      S.vacancy = await resolveVacancy(res.vacancy);
      renderVacancy(S.vacancy);

      const n = (S.vacancy.fields || []).length;
      const what = S.vacancy.saleKind ? `${S.vacancy.saleKind} 물건` : "매물";
      toast(`${what} 정보 ${n}개 항목을 가져왔습니다. 이제 사진을 찍습니다.`, "ok");

      /* 사진 4종 — 찍는 동안 공실열람 탭이 화면에 보여야 한다 */
      status("사진 찍는 중", "busy");
      GWBusy.label(el.btnGrab, "사진 찍는 중");
      S.media = GWMediaCover.normalize(await captureMedia(tab, S.vacancy));
      renderDraft();

      const shots = S.media.map((m) => m.kind);
      toast(
        `사진 ${S.media.length}장 준비됨 (${nounOf(S.vacancy)} ${shots.filter((k) => k === "photo").length}장 · 검증 · 지도 · 로드뷰)`,
        "ok",
        5000
      );
      status(`${nounOf(S.vacancy)} 준비됨`, "ok");
      save();
    })
  );

  /* 일반 매물은 "매물", 경매·공매는 "물건" */
  const nounOf = (v) => (v && v.saleKind ? "물건" : "매물");

  /* ═════════════ 일반 매물 / 경매·공매 가르기 ═════════════
     일반 매물은 화면의 공실광고정보 표를 그대로 쓴다.
     경매·공매 상세는 4개 탭으로 나뉘어 화면으로는 열린 탭만 읽히므로, 물건 정보를 서버에서 통째로 받는다.
     자동 판별은 서버에 경매·공매 물건인지 물어서 정한다. */
  const saleModeBtns = document.querySelectorAll(".chip[data-sale-mode]");
  saleModeBtns.forEach((btn) => {
    btn.addEventListener("click", () => {
      saleModeBtns.forEach((b) => b.classList.remove("active"));
      btn.classList.add("active");
      S.saleMode = btn.dataset.saleMode;
      save();
    });
  });

  async function resolveVacancy(domVacancy) {
    if (S.saleMode !== "listing") {
      const auction = await fetchAuction(domVacancy, S.saleMode === "auction");
      if (auction) return auction;
    }
    if (!(domVacancy.fields || []).length) {
      throw new Error("매물 상세 표를 읽지 못했습니다. 매물이 다 펼쳐진 뒤에 다시 눌러 주세요.");
    }
    return domVacancy;
  }

  /* 기사에 쓰지 않는 공고 부속 정보 — 정보제공처(온비드 고객센터 연락처)와 입찰 전 법적 주의사항 */
  const EXCLUDED_FACT = /정보\s*제공|고객\s*센터|주의\s*사항|1588-?5321/;

  /* 경매·공매 물건이면 서버 정보를, 아니면 null 을 돌려준다.
     strict(경매·공매를 직접 고른 경우)이면 경매·공매 물건이 아닐 때 오류로 알린다. */
  async function fetchAuction(domVacancy, strict) {
    const id = domVacancy.vacancyId;
    if (!id) {
      if (!strict) return null;
      throw new Error("물건 번호를 읽지 못했습니다. 공실열람에서 물건을 다시 펼친 뒤 눌러 주세요.");
    }

    const response = await fetch(`${S.origin}/api/extension/auction-source?id=${encodeURIComponent(id)}`, {
      credentials: "include",
      cache: "no-store",
    }).catch(() => null);
    const data = response ? await response.json().catch(() => null) : null;
    if (!data?.success) {
      /* 서버가 "경매·공매 물건이 아니다"라고 답했으면 일반 매물이다 */
      if (!strict && response && response.status >= 400 && response.status < 500) return null;
      throw new Error(
        (data && data.error) ||
        "경매·공매 물건인지 확인하지 못했습니다. 잠시 뒤 다시 누르거나, 일반 매물이면 1단계에서 [일반 매물]을 골라 주세요."
      );
    }

    return {
      vacancyId: data.id,
      saleKind: data.saleKind,
      title: data.title,
      priceText: data.priceText,
      location: data.location,
      propertyType: data.propertyType,
      detailPath: data.detailPath,
      fields: (data.facts || []).filter((f) => !EXCLUDED_FACT.test(`${f.label} ${f.value}`)),
      images: (domVacancy.images || []).length ? domVacancy.images : data.images || [],
      url: domVacancy.url,
    };
  }

  function renderVacancy(v) {
    const rows = [];
    if (v.priceText) rows.push(["금액", v.priceText]);
    for (const f of v.fields || []) rows.push([f.label, f.value]);
    if ((v.themes || []).length) rows.push(["특징", v.themes.join(" ")]);
    if (v.infra) rows.push(["주변환경", v.infra]);
    if ((v.images || []).length) rows.push(["등록 사진", `${v.images.length}장`]);

    el.vacancyKind.textContent = v.saleKind ? `가져온 ${v.saleKind} 물건` : "가져온 일반 매물";
    el.vacancyName.textContent = v.title || "-";
    el.vacancyFields.innerHTML = rows
      .map(([k, val]) => `<div class="vf-row"><dt>${esc(k)}</dt><dd>${esc(val)}</dd></div>`)
      .join("");
    el.vacancyCard.classList.remove("hidden");
  }

  /* ═════════════ 사진 4종 만들기 ═════════════ */
  async function captureMedia(tab, v) {
    const media = [];

    /* 1. 매물 등록 사진 — 있는 만큼 전부 */
    (v.images || []).forEach((url, i) => {
      media.push({ kind: "photo", url, caption: gwCaptionFor("photo", v, i) });
    });

    /* 캡쳐는 그 탭이 화면에 보일 때만 된다 */
    tab = await activateCaptureTab(tab);

    /* 2·3·4. 공실열람 검증 · 지도 · 로드뷰 */
    const failures = [];

    for (const shot of SHOTS) {
      const got = await captureOne(tab, shot);
      if (got.url) {
        media.push({ kind: shot.target, url: got.url, caption: gwCaptionFor(shot.target, v), real: true });
      } else {
        failures.push(`${shot.name}: ${got.reason}`);
        media.push({ kind: shot.target, url: shot.fallback(v), caption: gwCaptionFor(shot.target, v), real: false });
      }
    }

    await askTab(tab.id, { type: "GW_RESTORE_SCROLL" }).catch(() => {});

    /* 실패를 감추지 않는다. 무엇이 왜 안 됐는지 그대로 말한다. */
    if (failures.length) {
      console.warn("[공실뉴스] 캡쳐 실패\n" + failures.join("\n"));
      toast("캡쳐 안 된 것 — " + failures.join(" / "), "bad", 12000);
    }

    return media;
  }

  const SHOTS = [
    { target: "proof", name: "공실열람 검증", force16x9: true, fallback: gwProofCard },
    { target: "map", name: "지도", force16x9: false, fallback: gwMapCard },
    { target: "roadview", name: "로드뷰", force16x9: false, fallback: gwRoadviewCard },
  ];

  /* 화면 캡쳐는 초당 두 번까지만 허용된다. 그 간격을 지킨다. */
  let lastShotAt = 0;
  async function throttleShot() {
    const gap = Date.now() - lastShotAt;
    if (gap < 700) await sleep(700 - gap);
    lastShotAt = Date.now();
  }

  async function activateCaptureTab(tab) {
    if (!tab || !tab.id) throw new Error("캡쳐할 공실열람 탭이 없습니다.");

    const liveTab = await chrome.tabs.get(tab.id);
    await chrome.tabs.update(liveTab.id, { active: true });
    await chrome.windows.update(liveTab.windowId, { focused: true });
    await sleep(250);

    const [active] = await chrome.tabs.query({ active: true, windowId: liveTab.windowId });
    if (!active || active.id !== liveTab.id) {
      throw new Error("공실열람 탭을 화면 앞으로 가져오지 못했습니다.");
    }

    return active;
  }

  async function captureOne(tab, shot) {
    try {
      tab = await activateCaptureTab(tab);
    } catch (e) {
      return { url: null, reason: e.message || "공실열람 탭 활성화 실패" };
    }

    /* ① 찍을 곳으로 굴리고 좌표를 받는다 */
    let prep;
    try {
      prep = await askTab(tab.id, { type: "GW_PREPARE_SHOT", target: shot.target });
    } catch (e) {
      return { url: null, reason: e.message || "탭과 연결 안 됨" };
    }
    if (!prep.ok) return { url: null, reason: prep.reason || "화면에서 못 찾음" };

    /* ② 화면을 찍는다 — 한 번 실패하면 한 번 더 */
    let raw = null;
    let lastErr = "";
    for (let attempt = 0; attempt < 2 && !raw; attempt++) {
      await throttleShot();
      try {
        tab = await activateCaptureTab(tab);
        raw = await chrome.tabs.captureVisibleTab(tab.windowId, { format: "jpeg", quality: 90 });
      } catch (e) {
        lastErr = e.message || String(e);
        await sleep(500);
      }
    }
    if (!raw) return { url: null, reason: "화면 촬영 실패 — " + (lastErr || "알 수 없음") };

    /* ③ 좌표대로 잘라낸다 */
    const url = await gwCropRegion(raw, prep.rect, prep.viewport, shot.force16x9);
    if (!url) return { url: null, reason: "자르기 실패" };

    return { url, reason: "" };
  }

  /* 사진 한 장만 다시 찍기 */
  async function recapture(index) {
    const m = S.media[index];
    if (!m) return;
    const shot = SHOTS.find((s) => s.target === m.kind);
    if (!shot) {
      toast("이 사진은 다시 찍을 수 없습니다 (캡쳐로 만든 것이 아닙니다).", "bad");
      return;
    }

    let tab = S.gongsilTabId ? await chrome.tabs.get(S.gongsilTabId).catch(() => null) : null;
    if (!tab) tab = await findTab(GONGSIL_URLS);
    if (!tab) throw new Error("공실열람 탭이 없습니다.");

    await chrome.tabs.update(tab.id, { active: true });
    await chrome.windows.update(tab.windowId, { focused: true });
    await sleep(400);

    const got = await captureOne(tab, shot);
    await askTab(tab.id, { type: "GW_RESTORE_SCROLL" }).catch(() => {});

    if (!got.url) {
      toast(`${shot.name} 다시 찍기 실패 — ${got.reason}`, "bad", 9000);
      return;
    }

    S.media[index] = Object.assign({}, m, { url: got.url, real: true });
    renderDraft();
    save();
    toast(`${shot.name} 을(를) 다시 찍었습니다.`, "ok");
  }

  /* ═════════════ ③ AI 선택 ═════════════ */
  const platformBtns = document.querySelectorAll(".choice[data-platform]");
  platformBtns.forEach((btn) => {
    btn.addEventListener("click", () => {
      platformBtns.forEach((b) => b.classList.remove("active"));
      btn.classList.add("active");
      S.platform = btn.dataset.platform;
      S.aiTabId = null; /* AI 를 바꾸면 이전 탭은 우리 대화가 아니다 */
      refreshButtons();
      save();
    });
  });

  const aiConf = () => (S.platform === "gemini" ? GW.GEMINI : GW.CHATGPT);

  /* 자동 입력이 실패해도 붙여넣기로 이어갈 수 있게 AI 에 보낼 글을 미리 복사해 둔다.
     AI 탭으로 넘어가면 작업창이 초점을 잃어 복사가 막히므로 반드시 탭을 띄우기 전에 부른다. */
  const copyForPaste = (text) => navigator.clipboard.writeText(text).then(() => true, () => false);

  function pasteGuide(what) {
    const name = S.platform === "gemini" ? "Gemini" : "ChatGPT";
    const other = S.platform === "gemini" ? "ChatGPT" : "Gemini";
    return `${name} 입력칸에 ${what}을 자동으로 넣지 못했습니다. 복사해 두었으니 입력칸을 클릭하고 Ctrl+V 로 붙여넣은 뒤 직접 전송해 주세요. 계속 안 되면 2단계에서 ${other} 를 선택해 주세요.`;
  }

  /* ═════════════ 기사 스타일 · 분량 ═════════════ */
  const kindBtns = document.querySelectorAll(".choice[data-kind]");
  kindBtns.forEach((btn) => {
    btn.addEventListener("click", () => {
      kindBtns.forEach((b) => b.classList.remove("active"));
      btn.classList.add("active");
      S.kind = btn.dataset.kind;
      save();
    });
  });

  const lenBtns = document.querySelectorAll(".chip[data-length]");
  lenBtns.forEach((btn) => {
    btn.addEventListener("click", () => {
      lenBtns.forEach((b) => b.classList.remove("active"));
      btn.classList.add("active");
      S.length = btn.dataset.length;
      save();
    });
  });

  const promptOpts = () => ({ kind: S.kind, length: S.length });

  /* ═════════════ ④ AI 기사 작성 ═════════════ */
  el.btnOpenAi.addEventListener("click", () =>
    guard(el.btnOpenAi, "기사 작성 요청 중", async () => {
      if (!S.vacancy) throw new Error("먼저 [물건 가져오기] 를 해 주세요.");

      const conf = aiConf();
      const job = { type: "GW_FILL", text: gwBuildPrompt(S.vacancy, promptOpts()) };

      const copied = await copyForPaste(job.text);

      const tab = await chrome.tabs.create({ url: conf.URL, active: true });
      S.aiTabId = tab.id;
      save();

      await waitTabReady(tab.id);
      await sleep(1200);

      let res = await askTab(tab.id, job).catch((e) => ({ ok: false, reason: e.message }));

      /* 첫 화면이 덜 그려졌거나 탭 연결이 꼬이면 한 번 새로고침해서 다시 넣는다 */
      if (!res.ok) {
        status("AI 탭 새로고침 후 재시도", "busy");
        await chrome.tabs.reload(tab.id);
        await sleep(500);
        await waitTabReady(tab.id);
        await sleep(2000);
        res = await askTab(tab.id, job).catch((e) => ({ ok: false, reason: e.message }));
      }
      if (!res.ok) {
        if (!copied) throw new Error(res.reason || "프롬프트를 넣지 못했습니다.");
        toast(pasteGuide("프롬프트") + " 전송한 뒤에는 ③ 초안 보내기 로 이어가면 됩니다.", "bad", 15000);
        status("붙여넣기 필요", "bad");
        return;
      }

      const k = GW_KIND[S.kind] || GW_KIND.news;
      const l = GW_LENGTH[S.length] || GW_LENGTH.normal;
      toast(`${k.label} · ${l.chars} 로 프롬프트를 넣었습니다. ② 작성하기 를 누르세요.`, "ok", 6000);
      status("프롬프트 입력됨", "ok");
    }, { fail: el.articleFail, failTitle: "AI 기사 작성을 시작하지 못했습니다" })
  );

  function waitTabReady(tabId, timeoutMs = 30000) {
    return new Promise((resolve) => {
      const finish = () => {
        chrome.tabs.onUpdated.removeListener(onUpd);
        resolve();
      };
      const timer = setTimeout(finish, timeoutMs);
      const onUpd = (id, info) => {
        if (id === tabId && info.status === "complete") {
          clearTimeout(timer);
          finish();
        }
      };
      chrome.tabs.onUpdated.addListener(onUpd);
      chrome.tabs.get(tabId).then((t) => {
        if (t.status === "complete") {
          clearTimeout(timer);
          finish();
        }
      }).catch(() => {});
    });
  }

  /* ═════════════ ⑤ 작성하기 ═════════════ */
  el.btnSubmit.addEventListener("click", () =>
    guard(el.btnSubmit, "AI에 보내는 중", async () => {
      if (!S.aiTabId) throw new Error("먼저 ① AI 기사 작성 을 눌러 주세요.");
      await chrome.tabs.update(S.aiTabId, { active: true });
      const res = await askTab(S.aiTabId, { type: "GW_SUBMIT" });
      if (!res.ok) throw new Error(res.reason || "전송 버튼을 누르지 못했습니다.");
      toast("전송했습니다. 기사가 다 나오면 ③ 초안 보내기 를 누르세요.", "ok");
      status("AI 작성 중", "busy");
      setWriting(true);
    }, { fail: el.articleFail, failTitle: "AI에 보내지 못했습니다" })
  );

  /* ═════════════ ⑥ 초안 보내기 ═════════════ */
  const pasteBox = $("pasteBox");
  const pasteJson = $("pasteJson");

  el.btnPullDraft.addEventListener("click", () =>
    guard(el.btnPullDraft, "기사 가져오는 중", async () => {
      if (!S.aiTabId) throw new Error("먼저 ① AI 기사 작성 을 눌러 주세요.");
      let repaired;
      try {
        repaired = await pullArticle();
      } catch (e) {
        /* 자동으로 못 읽으면 직접 붙여넣는 길을 연다 */
        if (e.unreadable) {
          pasteJson.focus();
          toast(e.message, "bad", 9000);
          status("붙여넣기 필요", "bad");
          return;
        }
        throw e;
      }
      afterDraftPulled(repaired);
    }, { cover: el.draftBody, fail: el.articleFail, failTitle: "기사를 가져오지 못했습니다", retry: el.btnPullDraft })
  );

  $("btnPasteDraft").addEventListener("click", () =>
    guard($("btnPasteDraft"), "초안 만드는 중", async () => {
      const text = pasteJson.value.trim();
      if (!text) throw new Error("AI 답변의 JSON 을 먼저 붙여넣어 주세요.");
      afterDraftPulled(applyArticleText(text));
    })
  );

  function afterDraftPulled(repaired) {
    pasteBox.classList.add("hidden");
    pasteJson.value = "";
    toast(repaired ? "AI의 JSON 오류를 자동 복구해 초안을 가져왔습니다." : "초안을 가져왔습니다.", "ok");
    status("초안 준비됨", "ok");
    switchTab("draft");
  }

  async function pullArticle(readOpts = {}) {
    /* 새 답변을 기다리는 중(수정 요청 직후)이 아니면 복사 버튼부터 — 가장 정확하고 기다릴 필요도 없다 */
    if (!readOpts.minCount) {
      const direct = await GWChatGptDirect.read(S.aiTabId, (stage) => status(`기사 읽는 중 (${stage})`, "busy"));
      if (direct) return applyArticleText(direct);
    }

    let res = await askTab(S.aiTabId, { type: "GW_READ", ...readOpts });
    if (!res.ok && res.unreadable) {
      const direct = await GWChatGptDirect.read(S.aiTabId, (stage) => status(`기사 읽는 중 (${stage})`, "busy"));
      if (direct) res = { ok: true, text: direct };
    }
    if (!res.ok) {
      if (!res.unreadable) throw new Error(res.reason || "응답을 읽지 못했습니다.");
      /* 수정글도 같은 칸에 붙여넣으면 초안이 바뀐다 */
      pasteBox.classList.remove("hidden");
      const err = new Error(res.reason + " ① 물건·AI 탭 아래 붙여넣기 칸에 JSON 을 직접 붙여넣어 주세요.");
      err.unreadable = true;
      throw err;
    }
    return applyArticleText(res.text);
  }

  function applyArticleText(text) {
    const parsed = GWArticleJson.parse(text);
    if (!parsed.ok) {
      throw new Error(
        parsed.reason + " AI 탭에서 'JSON 형식으로 다시 출력해줘' 라고 한 번 더 요청한 뒤 다시 눌러 주세요."
      );
    }

    S.article = parsed.article;
    S.writing = false;
    showWriting();
    draftInsertSlot = null;
    pendingAiInsertSlot = null;
    pendingAiPreviousImage = null;
    pendingAiRequestKey = "";
    renderDraft();
    /* 글이 왔다는 걸 놓치지 않게 — 파란 테두리 + "아래로 내려서 확인" 안내 */
    window.GWArrival?.notify(el.draftBody.querySelector(".preview-doc"), el.viewDraft);
    save();
    return parsed.repaired === true;
  }

  /* ═════════════ 초안 미리보기 ═════════════ */

  /* 사진 한 장을 기사 안에 넣는 모양.
     contenteditable="false" 라 본문을 고쳐도 사진이 망가지지 않는다.
     설명글만 따로 고칠 수 있게 열어 둔다. */
  function figureHtml(m, idx) {
    const canReshoot = SHOTS.some((s) => s.target === m.kind);
    const warn = canReshoot && m.real === false
      ? `<span class="fig-warn">캡쳐 실패 · 대체 카드</span>`
      : "";
    const coverControl = m.isCover
      ? `<span class="fig-cover-mark">대표 이미지</span>`
      : `<button type="button" class="fig-btn cover" data-act="cover" data-mi="${idx}">대표지정</button>`;
    return (
      `<figure class="art-fig" contenteditable="false" data-mi="${idx}">` +
      `<img src="${esc(m.url)}" alt="">` +
      `<div class="fig-tools">` +
      coverControl +
      warn +
      `<button type="button" class="fig-btn" data-act="replace" data-mi="${idx}">사진 바꾸기</button>` +
      (canReshoot
        ? `<button type="button" class="fig-btn" data-act="reshoot" data-mi="${idx}">다시 찍기</button>`
        : "") +
      `<button type="button" class="fig-btn del" data-act="remove" data-mi="${idx}">삭제</button>` +
      `</div>` +
      `<figcaption class="art-cap" contenteditable="true" spellcheck="false">${esc(m.caption || "")}</figcaption>` +
      `</figure>`
    );
  }

  /* 사진 버튼은 새로 그릴 때마다 생기므로 위임해서 받는다 */
  let replaceIndex = -1;
  let fileInsertSlot = null;
  let pendingAiInsertSlot = null;
  let pendingAiPreviousImage = null;
  let pendingAiRequestKey = "";
  let draftInsertSlot = null;

  function directDraftParagraphs() {
    return Array.from(el.pvContent.children).filter((node) => node.tagName === "P");
  }

  /*
     커서는 버튼을 누르는 순간 본문에서 사라진다. 그래서 본문 안에서 움직일 때마다
     "앞에 문단이 몇 개 있는 자리인지"를 기억한다. 사진은 그 문단 슬롯에 꽂힌다.
  */
  function rememberDraftCursor() {
    const sel = window.getSelection();
    if (!sel || !sel.rangeCount || !S.article) return;

    const range = sel.getRangeAt(0);
    if (!el.pvContent.contains(range.startContainer) && range.startContainer !== el.pvContent) return;

    const paras = directDraftParagraphs();
    const startElm = range.startContainer.nodeType === Node.ELEMENT_NODE
      ? range.startContainer
      : range.startContainer.parentElement;
    const currentP = startElm && startElm.closest ? startElm.closest("p") : null;

    if (currentP && currentP.parentElement === el.pvContent) {
      const index = paras.indexOf(currentP);
      const beforeCaret = document.createRange();
      beforeCaret.selectNodeContents(currentP);
      try {
        beforeCaret.setEnd(range.startContainer, range.startOffset);
      } catch (e) {
        draftInsertSlot = Math.max(0, index + 1);
        return;
      }
      draftInsertSlot = Math.max(0, index + (beforeCaret.toString().length > 0 ? 1 : 0));
      return;
    }

    if (range.startContainer === el.pvContent) {
      draftInsertSlot = Array.from(el.pvContent.children)
        .slice(0, range.startOffset)
        .filter((node) => node.tagName === "P").length;
    }
  }

  /* 이미지를 넣을 자리 — 본문을 먼저 클릭했으면 그 자리, 아니면 첫 문단 다음 (블로그와 같다).
     예전에는 자리를 안 고르면 막았는데, 위쪽 안내를 못 보고 "버튼이 안 눌린다"고 느꼈다. */
  function requireDraftInsertSlot() {
    rememberDraftCursor();
    const length = directDraftParagraphs().length;
    if (!Number.isInteger(draftInsertSlot)) {
      toast("본문 첫 문단 다음에 넣습니다. 다른 자리에 넣으려면 본문에서 그 위치를 먼저 클릭하세요.", "info", 6000);
      return Math.min(1, length);
    }
    return Math.max(0, Math.min(draftInsertSlot, length));
  }

  function focusInsertedFigure(index) {
    requestAnimationFrame(() => {
      const fig = el.pvContent.querySelector(`.art-fig[data-mi="${index}"]`);
      if (!fig) return;
      fig.scrollIntoView({ behavior: "smooth", block: "center" });
      const range = document.createRange();
      range.setStartAfter(fig);
      range.collapse(true);
      const sel = window.getSelection();
      sel.removeAllRanges();
      sel.addRange(range);
      rememberDraftCursor();
    });
  }

  function onFigClick(e) {
    const btn = e.target.closest(".fig-btn");
    if (!btn) return;
    e.preventDefault();
    e.stopPropagation();

    const idx = Number(btn.dataset.mi);
    const act = btn.dataset.act;

    if (act === "cover") {
      /* 버튼 클릭 직전까지 고친 본문도 다시 그릴 때 잃지 않게 먼저 담는다. */
      harvestEdits();
      S.media = GWMediaCover.select(S.media, idx);
      renderDraft();
      save();
      toast("대표 이미지로 지정했습니다.", "ok");
      return;
    }

    if (act === "replace") {
      replaceIndex = idx;
      fileInsertSlot = null;
      el.fileImage.click();
      return;
    }

    if (act === "remove") {
      S.media.splice(idx, 1);
      S.media = GWMediaCover.normalize(S.media);
      renderDraft();
      save();
      toast("사진을 뺐습니다.", "ok");
      return;
    }

    if (act === "reshoot") {
      guard(btn, "다시 찍는 중", () => recapture(idx));
    }
  }

  el.pvContent.addEventListener("click", onFigClick);
  el.pvCover.addEventListener("click", onFigClick);
  ["mouseup", "keyup", "input", "focus"].forEach((eventName) => {
    el.pvContent.addEventListener(eventName, rememberDraftCursor);
  });
  document.addEventListener("selectionchange", rememberDraftCursor);

  function renderDraft() {
    const a = S.article;
    S.media = GWMediaCover.normalize(S.media);

    if (!a) {
      el.draftEmpty.classList.remove("hidden");
      el.draftBody.classList.add("hidden");
      el.draftActions.classList.add("hidden");
      /* 기사 전이라도 찍어 둔 사진은 볼 수 있게 한다 */
      renderCover();
      return;
    }

    el.draftEmpty.classList.add("hidden");
    el.draftBody.classList.remove("hidden");
    /* 하단 수정 바는 2번 탭을 보고 있을 때만 — 1번·3번 탭에서 다시 그려져도 튀어나오지 않게 */
    const onDraftTab = el.viewDraft.classList.contains("active");
    el.draftActions.classList.toggle("hidden", !onDraftTab);
    if (!onDraftTab) el.draftBadge.classList.remove("hidden");

    el.pvDate.textContent = new Date().toLocaleString("ko-KR", {
      year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit",
    });
    el.pvTitle.textContent = a.title || "";
    el.pvSubtitle.textContent = (a.subtitles || []).join("\n");
    el.pvKeywords.innerHTML = (a.keywords || [])
      .map((k) => `<span class="kw-tag">#${esc(k)}</span>`)
      .join("");

    renderCover();

    /* ── 본문과 사진을 번갈아 놓는다 ──
       첫 장은 제목 아래 대표로 올라갔으니, 나머지를 문단 사이에 하나씩 끼운다.
       "각각 내용 위에" — 사진이 그 다음 문단을 이끄는 모양이 된다. */
    const paras = String(a.body || "")
      .split(/\n{2,}|\n/)
      .map((s) => s.trim())
      .filter(Boolean);

    const rest = S.media
      .map((media, index) => ({ media, index }))
      .filter((item) => !item.media.isCover);
    const slots = Array.from({ length: paras.length + 1 }, () => []);
    const automatic = [];

    rest.forEach((item) => {
      if (Number.isInteger(item.media.insertAfterParagraph)) {
        const slot = Math.max(0, Math.min(item.media.insertAfterParagraph, paras.length));
        slots[slot].push(item);
      } else {
        automatic.push(item);
      }
    });

    /* 위치를 직접 지정하지 않은 기존 사진은 예전처럼 문단 사이에 자동 배치한다. */
    let autoIndex = 0;
    for (let slot = 1; slot < paras.length && autoIndex < automatic.length; slot += 1) {
      slots[slot].push(automatic[autoIndex]);
      autoIndex += 1;
    }
    while (autoIndex < automatic.length) {
      slots[paras.length].push(automatic[autoIndex]);
      autoIndex += 1;
    }

    const figuresAt = (slot) => slots[slot]
      .map((item) => figureHtml(item.media, item.index))
      .join("");

    let html = figuresAt(0);
    paras.forEach((p, i) => {
      const headingClass = p.startsWith("■") ? ' class="article-section-heading"' : "";
      html += `<p${headingClass}>${esc(p)}</p>`;
      html += figuresAt(i + 1);
    });

    el.pvContent.innerHTML = html;
    bindCaptionEdits();
  }

  function renderCover() {
    S.media = GWMediaCover.normalize(S.media);
    const coverIndex = GWMediaCover.indexOf(S.media);
    const cover = coverIndex >= 0 ? S.media[coverIndex] : null;
    if (!cover) {
      el.pvCover.classList.add("hidden");
      el.pvCover.innerHTML = "";
      return;
    }
    el.pvCover.classList.remove("hidden");
    el.pvCover.innerHTML = figureHtml(cover, coverIndex);
    bindCaptionEdits();
  }

  /* 설명글을 고치면 상태에 담는다 */
  function bindCaptionEdits() {
    document.querySelectorAll(".art-fig").forEach((fig) => {
      const idx = Number(fig.dataset.mi);
      const cap = fig.querySelector(".art-cap");
      if (!cap || cap.dataset.bound) return;
      cap.dataset.bound = "1";
      cap.addEventListener("blur", () => {
        if (S.media[idx]) S.media[idx].caption = cap.innerText.trim();
        save();
      });
    });
  }

  /* 손으로 고친 것을 상태에 담는다 — 보낼 때 그대로 나가야 한다.
     본문은 <p> 만 읽는다. 사진(figure)은 건드리지 않는다. */
  function harvestEdits() {
    if (!S.article) return;
    S.article.title = el.pvTitle.innerText.trim();
    S.article.subtitles = el.pvSubtitle.innerText.split("\n").map((s) => s.trim()).filter(Boolean);
    S.article.body = Array.from(el.pvContent.querySelectorAll("p"))
      .map((p) => p.innerText.trim())
      .filter(Boolean)
      .join("\n\n");
  }

  ["pvTitle", "pvSubtitle", "pvContent"].forEach((id) => {
    el[id].addEventListener("blur", () => {
      harvestEdits();
      save();
    });
  });

  /* ═════════════ ⑦ 수정 요청 ═════════════ */
  el.btnRevise.addEventListener("click", () => doRevise());
  el.reviseInput.addEventListener("keydown", (e) => {
    if (e.key === "Enter") doRevise();
  });

  function doRevise() {
    const want = el.reviseInput.value.trim();
    if (!want) {
      toast("고칠 점을 적어 주세요.", "bad");
      return;
    }
    guard(el.btnRevise, "수정 요청 중", async () => {
      if (!S.aiTabId || !(await chrome.tabs.get(S.aiTabId).catch(() => null))) {
        S.aiTabId = null;
        throw new Error("기사를 쓴 AI 탭이 닫혔습니다. ① 물건·AI 탭에서 [AI 기사 작성]으로 새로 만들어 주세요.");
      }

      harvestEdits();
      const text = gwBuildRevisePrompt(want, S.vacancy);
      const copied = await copyForPaste(text);
      await chrome.tabs.update(S.aiTabId, { active: true });
      /* ChatGPT: AI 가 아직 답하는 중이면 기다리고, 보내기 전 대화 메시지 수를 세어 둔다 */
      const api = await GWChatGptDirect.waitIdle(S.aiTabId, () => status("AI 답변이 끝나길 기다리는 중", "busy"));
      // 보내기 전 답변 수를 세어 두었다가 새 답변만 읽는다 (예전 AI 탭이면 세지 못한다)
      const before = await askTab(S.aiTabId, { type: "GW_COUNT" }).catch(() => null);

      const fill = await askTab(S.aiTabId, { type: "GW_FILL", text }).catch((e) => ({ ok: false, reason: e.message }));
      if (!fill.ok) {
        if (!copied) throw new Error(fill.reason || "수정 요청을 넣지 못했습니다.");
        toast(pasteGuide("수정 요청") + " 답변이 끝나면 [수정글 가져오기]를 눌러 주세요.", "bad", 15000);
        status("붙여넣기 필요", "bad");
        return;
      }

      const sent = await askTab(S.aiTabId, { type: "GW_SUBMIT" });
      if (!sent.ok) throw new Error(sent.reason || "전송하지 못했습니다.");

      el.reviseInput.value = "";
      GWBusy.label(el.btnRevise, "AI가 기사를 수정하는 중");
      status("AI가 기사를 수정하는 중", "busy");

      /* ChatGPT 는 대화 원문에서 "새로 끝난 AI 답변"만 받는다 — 보낸 양식·이전 답변이 섞이지 않는다 */
      if (api.ok) {
        const answer = await GWChatGptDirect.waitNewAnswer(S.aiTabId, api.messageCount, 240000);
        if (answer) {
          const repaired = applyArticleText(answer);
          toast(repaired ? "JSON 오류를 자동 복구해 수정 기사를 가져왔습니다." : "수정된 기사를 가져왔습니다.", "ok");
          status("초안 갱신됨", "ok");
          return;
        }
        if (!(await chrome.tabs.get(S.aiTabId).catch(() => null))) {
          throw new Error("AI 탭이 닫혀 수정 기사를 받지 못했습니다.");
        }
        /* 원문으로 못 받았으면 아래 화면 읽기로 한 번 더 시도한다 */
      }

      if (!before?.ok) {
        toast("수정을 요청했습니다. AI 답변이 끝나면 [수정글 가져오기]를 눌러 주세요.", "info", 9000);
        status("수정 답변 기다리는 중", "busy");
        return;
      }
      toast("수정을 요청했습니다. 새 답변이 끝나면 자동으로 가져옵니다.", "info");
      const repaired = await pullArticle({ minCount: before.count + 1, maxMs: 180000 });
      toast(repaired ? "JSON 오류를 자동 복구해 수정 기사를 가져왔습니다." : "수정된 기사를 가져왔습니다.", "ok");
      status("초안 갱신됨", "ok");
    }, { cover: el.draftBody, failTitle: "수정 기사를 받지 못했습니다", retry: el.btnPullRevised });
  }

  el.btnPullRevised.addEventListener("click", () =>
    guard(el.btnPullRevised, "수정글 가져오는 중", async () => {
      if (!S.aiTabId) throw new Error("AI 탭이 없습니다. 초안을 만든 탭이 닫혔습니다.");
      const repaired = await pullArticle();
      toast(repaired ? "JSON 오류를 자동 복구해 수정 기사를 가져왔습니다." : "수정된 기사를 가져왔습니다.", "ok");
      status("초안 갱신됨", "ok");
    }, { cover: el.draftBody, failTitle: "수정 기사를 가져오지 못했습니다", retry: el.btnPullRevised })
  );

  /* ═════════════ ⑦ 이미지 ═════════════ */
  const imageStyleBtns = document.querySelectorAll(".image-style[data-image-style]");
  imageStyleBtns.forEach((btn) => {
    btn.addEventListener("click", () => {
      imageStyleBtns.forEach((b) => b.classList.remove("active"));
      btn.classList.add("active");
      S.imageStyle = btn.dataset.imageStyle;
      S.customStyle = "";
      if (el.imageCustomStyle) {
        el.imageCustomStyle.value = "";
        el.imageCustomStyle.classList.remove("active");
      }
      save();
    });
  });

  if (el.imageCustomStyle) {
    ["input", "change"].forEach((evt) => {
      el.imageCustomStyle.addEventListener(evt, () => {
        S.customStyle = el.imageCustomStyle.value.trim();
        const hasCustom = Boolean(S.customStyle);
        el.imageCustomStyle.classList.toggle("active", hasCustom);
        if (hasCustom) {
          imageStyleBtns.forEach((b) => b.classList.remove("active"));
        } else {
          imageStyleBtns.forEach((b) => b.classList.toggle("active", b.dataset.imageStyle === S.imageStyle));
        }
        save();
      });
    });
  }

  ["input", "change"].forEach((evt) => {
    el.imageRequest.addEventListener(evt, () => {
      S.imageRequest = el.imageRequest.value.trim();
      save();
    });
  });

  el.btnMakeImage.addEventListener("click", () =>
    guard(el.btnMakeImage, "이미지 요청 중", async () => {
      if (!S.aiTabId) throw new Error("AI 탭이 없습니다.");
      if (!S.article) throw new Error("먼저 초안을 가져와 주세요.");

      S.imageRequest = el.imageRequest.value.trim();
      S.customStyle = el.imageCustomStyle ? el.imageCustomStyle.value.trim() : "";
      const currentRequestKey = JSON.stringify([S.imageStyle, S.customStyle, S.imageRequest]);

      /* 이전 요청과 다른 스타일·내용이면 기다리지 않고 새 이미지 요청으로 전환한다. */
      if (Number.isInteger(pendingAiInsertSlot) && pendingAiRequestKey !== currentRequestKey) {
        pendingAiInsertSlot = null;
        pendingAiPreviousImage = null;
        pendingAiRequestKey = "";
      }

      const slot = Number.isInteger(pendingAiInsertSlot)
        ? pendingAiInsertSlot
        : requireDraftInsertSlot();
      if (!Number.isInteger(slot)) return;

      /* 요청한 뒤 두 번째 클릭이면 새로 완성된 그림만 집는다. */
      if (Number.isInteger(pendingAiInsertSlot)) {
        const already = await askTab(S.aiTabId, { type: "GW_GET_IMAGE" }).catch(() => null);
        const beforeCount = Number(pendingAiPreviousImage && pendingAiPreviousImage.count) || 0;
        const nowCount = Number(already && already.count) || 0;
        const isNewImage = already && already.ok && already.url &&
          (already.url !== (pendingAiPreviousImage && pendingAiPreviousImage.url) || nowCount > beforeCount) &&
          !S.media.some((m) => m.url === already.url);

        if (isNewImage) {
          addAiImage(already.url, slot);
          pendingAiInsertSlot = null;
          pendingAiPreviousImage = null;
          pendingAiRequestKey = "";
          toast("AI 이미지를 커서 위치에 넣었습니다.", "ok");
          return;
        }

        toast("AI 이미지가 아직 만들어지는 중입니다. 완성된 뒤 다시 눌러 주세요.", "info", 5000);
        status("이미지 생성 중", "busy");
        return;
      }

      harvestEdits();
      save();
      const beforeImage = await askTab(S.aiTabId, { type: "GW_GET_IMAGE" }).catch(() => null);
      pendingAiPreviousImage = beforeImage && beforeImage.ok
        ? { url: beforeImage.url, count: Number(beforeImage.count) || 0 }
        : { url: "", count: 0 };
      const text = gwBuildImagePrompt(S.vacancy, S.article, {
        style: S.imageStyle,
        customStyle: S.customStyle,
        request: S.imageRequest,
      });
      const copied = await copyForPaste(text);
      await chrome.tabs.update(S.aiTabId, { active: true });

      const fill = await askTab(S.aiTabId, { type: "GW_FILL", text }).catch((e) => ({ ok: false, reason: e.message }));
      if (!fill.ok) {
        if (!copied) throw new Error(fill.reason || "이미지 요청을 넣지 못했습니다.");
        /* 붙여넣어 보낸 그림도 다음 클릭에 가져올 수 있게 요청한 것으로 기억한다 */
        pendingAiInsertSlot = slot;
        pendingAiRequestKey = currentRequestKey;
        toast(pasteGuide("이미지 요청") + " 그림이 다 나온 뒤 [AI 이미지 만들기]를 한 번 더 누르세요.", "bad", 15000);
        status("붙여넣기 필요", "bad");
        return;
      }

      const sent = await askTab(S.aiTabId, { type: "GW_SUBMIT" });
      if (!sent.ok) throw new Error(sent.reason || "전송하지 못했습니다.");

      pendingAiInsertSlot = slot;
      pendingAiRequestKey = currentRequestKey;
      const imageStyle = GW_IMAGE_STYLE[S.imageStyle] || GW_IMAGE_STYLE.news;
      toast(`${imageStyle.label} 이미지를 요청했습니다. 그림이 다 나온 뒤 [AI 이미지 만들기] 를 한 번 더 누르세요.`, "info", 7000);
      status("이미지 생성 중", "busy");
    })
  );

  function addAiImage(url, insertAfterParagraph) {
    S.media.push({
      kind: "ai",
      url,
      caption: gwCaptionFor("photo", S.vacancy || {}, 0),
      insertAfterParagraph,
    });
    const insertedIndex = S.media.length - 1;
    renderDraft();
    save();
    focusInsertedFigure(insertedIndex);
    status("이미지 추가됨", "ok");
  }

  /* 하단 바의 [이미지 삽입] 은 PC 사진을 커서 위치에 넣는다. */
  el.btnChangeImage.addEventListener("click", () => {
    const slot = requireDraftInsertSlot();
    if (!Number.isInteger(slot)) return;
    replaceIndex = -1;
    fileInsertSlot = slot;
    el.fileImage.click();
  });

  el.fileImage.addEventListener("change", () => {
    const file = el.fileImage.files && el.fileImage.files[0];
    el.fileImage.value = "";
    if (!file) return;

    const idx = replaceIndex;
    const slot = fileInsertSlot;
    replaceIndex = -1;
    fileInsertSlot = null;

    const reader = new FileReader();
    reader.onload = () => {
      const url = reader.result;
      if (idx >= 0 && S.media[idx]) {
        S.media[idx] = Object.assign({}, S.media[idx], { url, kind: "upload", real: true });
        toast(`${idx === 0 ? "대표 " : ""}사진을 바꿨습니다.`, "ok");
      } else {
        S.media.push({
          kind: "upload",
          url,
          caption: "",
          real: true,
          insertAfterParagraph: Number.isInteger(slot) ? slot : directDraftParagraphs().length,
        });
        toast("사진을 커서 위치에 넣었습니다.", "ok");
      }
      const insertedIndex = idx >= 0 ? idx : S.media.length - 1;
      renderDraft();
      save();
      if (idx < 0) focusInsertedFigure(insertedIndex);
    };
    reader.onerror = () => toast("이미지를 읽지 못했습니다.", "bad");
    reader.readAsDataURL(file);
  });

  /* ═════════════ ⑨ 기사전송하기 ═════════════ */
  el.btnSendGongsil.addEventListener("click", () =>
    guard(el.btnSendGongsil, "기사 전송 중", async () => {
      if (!S.article) throw new Error("보낼 초안이 없습니다.");

      harvestEdits();

      if (!S.article.title || !S.article.body) {
        throw new Error("제목과 본문이 있어야 보낼 수 있습니다.");
      }

      /* 기사쓰기 폼(공실뉴스 페이지)은 온비드 같은 바깥 사진을 직접 받지 못한다.
         작업창에서 미리 받아 JPG 로 바꿔 넘긴다. */
      GWBusy.label(el.btnSendGongsil, "사진 준비 중");
      const prepared = await gwMediaToDataUrls(GWMediaCover.coverFirst(S.media));
      if (prepared.failed.length) {
        toast(`사진 ${prepared.failed.length}장을 받지 못해 빼고 보냅니다. 기사쓰기 화면에서 직접 올려 주세요.`, "bad", 9000);
      }
      GWBusy.label(el.btnSendGongsil, "기사 전송 중");

      const res = await chrome.runtime.sendMessage({
        type: "GW_SEND_TO_GONGSIL",
        article: S.article,
        /* 대표를 첫 순서로도 보낸다. isCover 를 모르는 구버전 기사작성 폼도 안전하다. */
        media: prepared.media.filter((item, index) => !prepared.failed.includes(index)),
        vacancyId: S.vacancy?.vacancyId || null,
        /* 경매·공매 기사는 기사쓰기 폼에서 섹션(공실뉴스 > 경매/공매)까지 고른다 */
        saleKind: S.vacancy?.saleKind || null,
      });

      if (!res || !res.ok) throw new Error((res && res.error) || "기사쓰기 폼에 초안을 넣지 못했습니다.");

      toast("열어 둔 기사쓰기 폼에 초안을 채웠습니다. 확인 후 [기사 등록]을 눌러 주세요.", "ok", 7000);
      status("전송 완료", "ok");
    })
  );

  /* ═════════════ AI 작성 중 안내 ═════════════
     [작성하기]로 보낸 뒤 [초안 보내기]로 가져올 때까지 띄워 둔다. */
  function showWriting() {
    GWBusy.writing(el.articleWriting, Boolean(S.writing), "AI가 기사를 작성 중입니다", "다 쓰면 이 안내가 꺼집니다. 그때 ③ 초안 보내기를 누르세요");
    /* AI 가 다 쓰면 안내만 끈다 — 가져오기는 [초안 보내기]로 직접 한다 */
    if (S.writing) {
      GWBusy.watchAi("article", () => S.aiTabId, () => S.writing, (why) => {
        setWriting(false);
        status(why === "closed" ? "AI 탭이 닫힘" : "기사 작성 완료", why === "closed" ? "" : "ok");
      });
    }
  }

  function setWriting(on) {
    S.writing = on;
    showWriting();
    save();
  }

  /* ═════════════ 탭 전환 ═════════════ */
  function switchTab(which) {
    /* 3번 블로그·4번 유튜브 탭과 그 하단 바는 blog.js·youtube.js 가 관리한다. 1·2번으로 올 때 내려놓는다. */
    ["tabBlog", "viewBlog", "viewSns", "tabScript", "viewScript"].forEach((id) => $(id)?.classList.remove("active"));
    ["blogActions", "snsActions", "scriptActions", "channelBar"].forEach((id) => $(id)?.classList.add("hidden"));
    document.dispatchEvent(new CustomEvent("gw:leave-youtube"));
    const work = which === "work";
    el.tabWork.classList.toggle("active", work);
    el.tabDraft.classList.toggle("active", !work);
    el.viewWork.classList.toggle("active", work);
    el.viewDraft.classList.toggle("active", !work);
    el.draftActions.classList.toggle("hidden", work || !S.article);
    if (!work) el.draftBadge.classList.add("hidden");
  }

  el.tabWork.addEventListener("click", () => switchTab("work"));
  el.tabDraft.addEventListener("click", () => switchTab("draft"));

  /* ═════════════ 버튼 잠금 ═════════════ */
  function refreshButtons() {
    el.btnOpenAi.disabled = !S.vacancy;
    el.btnSubmit.disabled = !S.aiTabId;
    el.btnPullDraft.disabled = !S.aiTabId;
    el.btnRevise.disabled = !S.article || !S.aiTabId;
    el.btnPullRevised.disabled = !S.aiTabId;
    el.btnMakeImage.disabled = !S.article || !S.aiTabId;
    el.btnChangeImage.disabled = !S.article;
    el.btnSendGongsil.disabled = !S.article;
  }

  /* ═════════════ 상태 보관 ═════════════ */
  const STATE_KEY = "gw_panel_state";

  let lastSaveError = "";

  function save() {
    chrome.storage.local.set({ [STATE_KEY]: S }).catch((e) => {
      const msg = e.message || String(e);
      console.warn("[공실뉴스] 상태 저장 실패:", msg);
      /* 같은 말을 반복해서 띄우지 않는다 */
      if (msg !== lastSaveError) {
        lastSaveError = msg;
        toast("작업 내용을 저장하지 못했습니다 — " + msg, "bad", 9000);
      }
    });
  }

  async function restore() {
    const got = await chrome.storage.local.get(STATE_KEY);
    const prev = got[STATE_KEY];
    if (!prev) return;
    Object.assign(S, prev);
    if (!Array.isArray(S.media)) S.media = [];
    S.media = GWMediaCover.normalize(S.media);
    /* 예전 3가지 기사 성격을 저장한 사용자는 현재 기사형으로 안전하게 옮긴다. */
    if (["listing", "area", "tenant"].includes(S.kind)) S.kind = "news";
    if (!GW_KIND[S.kind]) S.kind = "news";
    if (!GW_LENGTH[S.length]) S.length = "normal";
    if (!GW_IMAGE_STYLE[S.imageStyle]) S.imageStyle = "news";
    if (!["auto", "listing", "auction"].includes(S.saleMode)) S.saleMode = "auto";
    if (typeof S.customStyle !== "string") S.customStyle = "";
    if (typeof S.imageRequest !== "string") S.imageRequest = "";

    platformBtns.forEach((b) => b.classList.toggle("active", b.dataset.platform === S.platform));
    saleModeBtns.forEach((b) => b.classList.toggle("active", b.dataset.saleMode === S.saleMode));
    kindBtns.forEach((b) => b.classList.toggle("active", b.dataset.kind === S.kind));
    lenBtns.forEach((b) => b.classList.toggle("active", b.dataset.length === S.length));
    imageStyleBtns.forEach((b) => b.classList.toggle("active", !S.customStyle && b.dataset.imageStyle === S.imageStyle));
    if (el.imageCustomStyle) {
      el.imageCustomStyle.value = S.customStyle;
      el.imageCustomStyle.classList.toggle("active", Boolean(S.customStyle));
    }
    el.imageRequest.value = S.imageRequest;

    /* 기억해 둔 탭이 아직 살아 있는지 확인한다 */
    for (const key of ["gongsilTabId", "aiTabId"]) {
      if (S[key]) {
        const alive = await chrome.tabs.get(S[key]).catch(() => null);
        if (!alive) S[key] = null;
      }
    }

    if (S.vacancy) renderVacancy(S.vacancy);
    if (!S.aiTabId) S.writing = false; // 기사를 쓰던 AI 탭이 닫혔으면 안내도 내린다
    showWriting();
    renderDraft();
  }

  /* ═════════════ 초기화 ═════════════
     [↺ 초기화 ▾] → [이 탭만 초기화] / [전체 초기화].
     어느 쪽이든 글만 지우고, 고른 AI와 스타일 설정은 남긴다.
     저장소를 고친 뒤 작업창을 새로 불러오고, 보던 탭으로 돌아온다.
     앞 탭을 지워도 뒤 탭(블로그·대본)은 이미 만든 결과물이라 남긴다. */
  const BLOG_STATE_KEY = "gw_blog_state";
  const SNS_STATE_KEY = "gw_sns_state";
  const YOUTUBE_STATE_KEY = "gw_youtube_state";
  const RETURN_TAB_KEY = "gw_return_tab"; // 새로 불러온 뒤 돌아갈 탭 (sessionStorage)

  const RESET_TABS = {
    tabWork: {
      label: "1 물건·AI",
      what: "가져온 물건과 기사 초안·사진이 지워집니다.\n블로그·SNS 글과 유튜브 대본은 남습니다.",
    },
    tabDraft: {
      label: "2 초안 다듬기",
      what: "기사 초안과 AI·삽입 사진이 지워집니다.\n가져온 물건은 남아서 같은 물건으로 다시 쓸 수 있습니다.",
    },
    tabBlog: { label: "3 블로그·SNS — 블로그", what: "블로그 글만 지워집니다.\n물건·기사·SNS 글·유튜브 대본은 남습니다." },
    tabScript: { label: "4 유튜브 대본", what: "유튜브 대본만 지워집니다.\n물건·기사·블로그·SNS 글은 남습니다." },
  };
  /* 3번 탭에서 SNS(페이스북·인스타·스레드)를 보고 있으면 SNS 만 지운다 (sns.js) */
  const RESET_SNS = {
    label: "3 블로그·SNS — SNS",
    what: "페이스북·인스타그램·스레드 글과 사진만 지워집니다.\n물건·기사·블로그 글·유튜브 대본은 남습니다.",
  };
  const snsActive = () => Boolean($("viewSns")?.classList.contains("active"));
  const resetInfo = (tabId) => (tabId === "tabBlog" && snsActive() ? RESET_SNS : RESET_TABS[tabId]);

  const activeTabId = () => Object.keys(RESET_TABS).find((id) => $(id)?.classList.contains("active")) || "tabWork";

  /* 물건·초안을 비운 1·2번 탭 상태 — 설정은 그대로 */
  const panelSettings = () => ({
    platform: S.platform,
    saleMode: S.saleMode,
    kind: S.kind,
    length: S.length,
    imageStyle: S.imageStyle,
  });

  async function blankBlog() {
    const blog = (await chrome.storage.local.get(BLOG_STATE_KEY))[BLOG_STATE_KEY] || {};
    return { style: blog.style, length: blog.length, imageStyle: blog.imageStyle, design: blog.design };
  }

  async function blankSns() {
    const sns = (await chrome.storage.local.get(SNS_STATE_KEY))[SNS_STATE_KEY] || {};
    return { channel: sns.channel, imageStyle: sns.imageStyle };
  }

  async function blankYoutube() {
    const youtube = (await chrome.storage.local.get(YOUTUBE_STATE_KEY))[YOUTUBE_STATE_KEY] || {};
    return { settings: youtube.settings };
  }

  async function runReset(scope) {
    const tabId = activeTabId();
    const message = scope === "all"
      ? "가져온 물건, 초안, 사진, 블로그·SNS 글, 유튜브 대본이 모두 지워집니다.\n전체 초기화할까요?"
      : `[${resetInfo(tabId).label}] 탭만 초기화합니다.\n\n${resetInfo(tabId).what}\n\n초기화할까요?`;
    if (!confirm(message)) return;
    try {
      if (scope === "all") {
        await chrome.storage.local.set({
          [STATE_KEY]: panelSettings(),
          [BLOG_STATE_KEY]: await blankBlog(),
          [SNS_STATE_KEY]: await blankSns(),
          [YOUTUBE_STATE_KEY]: await blankYoutube(),
        });
        await chrome.storage.local.remove([GW.KEY.JOB, GW.KEY.DRAFT]).catch(() => {});
      } else if (tabId === "tabWork") {
        await chrome.storage.local.set({ [STATE_KEY]: panelSettings() });
        await chrome.storage.local.remove([GW.KEY.JOB, GW.KEY.DRAFT]).catch(() => {});
      } else if (tabId === "tabDraft") {
        /* 물건에서 가져온 사진은 남기고, 초안 단계에서 더한 AI·삽입 사진만 뺀다 */
        const media = (S.media || []).filter((m) => m.kind !== "ai" && !Number.isInteger(m.insertAfterParagraph));
        await chrome.storage.local.set({
          [STATE_KEY]: Object.assign({}, S, { article: null, writing: false, imageRequest: "", media }),
        });
        await chrome.storage.local.remove(GW.KEY.DRAFT).catch(() => {});
      } else if (tabId === "tabBlog" && snsActive()) {
        await chrome.storage.local.set({ [SNS_STATE_KEY]: await blankSns() });
      } else if (tabId === "tabBlog") {
        await chrome.storage.local.set({ [BLOG_STATE_KEY]: await blankBlog() });
      } else if (tabId === "tabScript") {
        await chrome.storage.local.set({ [YOUTUBE_STATE_KEY]: await blankYoutube() });
      }
      try { sessionStorage.setItem(RETURN_TAB_KEY, scope === "all" ? "tabWork" : tabId); } catch {}
      location.reload();
    } catch (e) {
      toast("초기화하지 못했습니다 — " + (e.message || String(e)), "bad", 7000);
    }
  }

  const resetMenu = $("resetMenu");
  const btnReset = $("btnReset");

  function closeResetMenu() {
    resetMenu.classList.add("hidden");
    btnReset.setAttribute("aria-expanded", "false");
  }

  btnReset.addEventListener("click", (e) => {
    e.stopPropagation();
    if (!resetMenu.classList.contains("hidden")) { closeResetMenu(); return; }
    $("resetTabLabel").textContent = resetInfo(activeTabId()).label;
    resetMenu.classList.remove("hidden");
    btnReset.setAttribute("aria-expanded", "true");
  });
  $("btnResetTab").addEventListener("click", () => { closeResetMenu(); runReset("tab"); });
  $("btnResetAll").addEventListener("click", () => { closeResetMenu(); runReset("all"); });
  document.addEventListener("click", (e) => {
    if (!resetMenu.contains(e.target)) closeResetMenu();
  });
  document.addEventListener("keydown", (e) => { if (e.key === "Escape") closeResetMenu(); });

  /* ═════════════ 잡동사니 ═════════════ */
  function esc(str) {
    return String(str == null ? "" : str)
      .replace(/&/g, "&amp;").replace(/</g, "&lt;")
      .replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  }

  /* ═════════════ 시작 ═════════════ */
  $("brandVersion").textContent = "v" + chrome.runtime.getManifest().version;
  (async () => {
    await restore();
    refreshButtons();
    status(S.article ? "초안 있음" : S.vacancy ? `${nounOf(S.vacancy)} 준비됨` : "준비됨", S.article ? "ok" : "");
    /* 탭만 초기화한 뒤라면 보던 탭으로 돌아간다 */
    let back = null;
    try { back = sessionStorage.getItem(RETURN_TAB_KEY); sessionStorage.removeItem(RETURN_TAB_KEY); } catch {}
    if (back && back !== "tabWork" && RESET_TABS[back]) setTimeout(() => $(back)?.click(), 0);
  })();
})();
