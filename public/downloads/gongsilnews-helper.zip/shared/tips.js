/* ══════════════════════════════════════════════════════════════
   버튼 설명 말풍선 — 마우스를 올리면 바로 "무엇을 하는지 · 언제 누르는지"를 보여 준다.

   설명은 아래 TIPS 에 모아 둔다 (선택자 → 문장). 여기 없는 버튼은
   원래 붙어 있던 title 을 말풍선으로 보여 준다 (브라우저 기본 설명은 늦게·작게 떠서).
   ══════════════════════════════════════════════════════════════ */
(function () {
  const TIPS = {
    /* 상단 */
    "#btnReset": "지금 보는 탭만 지우거나, 물건·기사·블로그·대본을 모두 지우고 처음부터 시작합니다. 고른 AI·스타일 설정은 남습니다.",
    "#tabWork": "1단계 — 매물을 가져오고 AI에게 기사를 쓰게 합니다.",
    "#tabDraft": "2단계 — AI가 쓴 기사를 확인·수정하고 공실뉴스로 보냅니다.",
    "#tabBlog": "3단계 — 완성된 기사를 바탕으로 네이버 블로그 글과 페이스북·인스타그램·스레드 글을 만듭니다.",
    "#tabScript": "4단계 — 같은 매물로 유튜브 영상 대본을 만듭니다.",

    /* 1단계 */
    '[data-sale-mode="auto"]': "일반 매물인지 경매·공매인지 자동으로 알아봅니다. 보통은 이대로 두면 됩니다.",
    '[data-sale-mode="listing"]': "자동 판별이 틀렸을 때 — 일반 공실 광고 매물로 기사를 씁니다.",
    '[data-sale-mode="auction"]': "자동 판별이 틀렸을 때 — 경매·공매 물건으로 기사를 씁니다.",
    "#btnGoGongsil": "공실열람 페이지를 엽니다. 기사로 쓸 매물의 상세 화면을 띄운 뒤 [물건 가져오기]를 누르세요.",
    "#btnGrab": "지금 열려 있는 공실 상세 화면의 매물 정보와 사진을 가져옵니다. 매물 상세 화면을 먼저 띄워 두세요.",
    '[data-platform="chatgpt"]': "ChatGPT로 기사를 씁니다. chatgpt.com 에 로그인되어 있어야 합니다.",
    '[data-platform="gemini"]': "Gemini로 기사를 씁니다. gemini.google.com 에 로그인되어 있어야 합니다.",
    '[data-kind="news"]': "자연스럽게 이어지는 일반 뉴스 기사 형식입니다.",
    '[data-kind="summary"]': "도입 요약 뒤 ■ 소제목으로 내용을 나눈 기사 형식입니다.",
    '[data-length="short"]': "700~1,000자 정도의 짧은 기사입니다.",
    '[data-length="normal"]': "1,400~1,800자 정도의 보통 길이 기사입니다.",
    '[data-length="long"]': "2,800~3,500자 정도의 긴 기사입니다.",
    "#btnOpenAi": "AI(ChatGPT·Gemini) 탭을 열고 기사 요청 문장을 자동으로 채웁니다. 다음은 [② 작성하기]입니다.",
    "#btnSubmit": "AI 창에 채워 둔 요청을 전송합니다. AI가 기사를 다 쓸 때까지 1~2분 기다린 뒤 [③ 초안 보내기]를 누르세요.",
    "#btnPullDraft": "AI가 다 쓴 기사를 이 작업창으로 가져옵니다. AI 답변이 끝까지 나온 뒤에 누르세요.",
    "#btnPasteDraft": "자동으로 못 가져왔을 때 — AI 답변을 직접 복사해 붙여 넣고 누르면 초안이 만들어집니다.",

    /* 2단계 */
    "#btnRevise": "왼쪽 칸에 적은 고칠 점을 같은 AI 대화에 보냅니다. 답이 끝나면 고친 글을 자동으로 가져옵니다.",
    "#btnPullRevised": "수정 요청 후 AI 답변이 끝났는데 글이 바뀌지 않았다면 눌러서 고친 글을 가져옵니다.",
    '.image-opts-toggle[data-target="imageOpts"]': "AI 이미지 스타일과 설명 칸을 펼칩니다. 스타일을 고르고 [AI 이미지 만들기]를 누르세요.",
    "#btnChangeImage": "본문에서 사진을 넣을 위치를 먼저 클릭한 뒤 누르면, 내 PC의 사진을 그 자리에 넣습니다.",
    "#btnMakeImage": "고른 스타일과 설명대로 AI가 기사용 이미지를 만듭니다. 설명을 비워 두면 기사 내용에서 알아서 고릅니다.",
    ".btn-article-shortcut": "공실뉴스 새 기사쓰기 화면을 새 탭으로 엽니다. 로그인한 뒤 [기사전송하기]를 누르세요.",
    "#btnSendGongsil": "완성된 제목·본문·사진을 열어 둔 공실뉴스 새 기사쓰기 화면에 채웁니다. 먼저 [기사작성 바로가기]로 그 화면을 열어 두세요.",

    /* 3단계 */
    "#btnMakeBlogDraft": "고른 블로그 스타일과 길이로 AI에게 블로그 글을 요청합니다. 다 쓰면 [완성 글 가져오기]를 누르세요.",
    "#btnPullBlogDraft": "AI가 다 쓴 블로그 제목과 본문을 이 탭으로 가져옵니다. AI 답변이 끝까지 나온 뒤에 누르세요.",
    "#btnReviseBlog": "왼쪽 칸에 적은 고칠 점을 AI에 보내 블로그 글을 고칩니다. 답이 끝나면 자동으로 가져옵니다.",
    "#btnPullBlogRevised": "수정 요청 후 글이 바뀌지 않았다면 눌러서 고친 블로그 글을 가져옵니다.",
    '.image-opts-toggle[data-target="blogImageOpts"]': "블로그용 AI 이미지 스타일과 설명 칸을 펼칩니다.",
    "#btnInsertBlogImage": "본문에서 위치를 먼저 클릭한 뒤 누르면, 내 PC의 사진을 그 자리에 넣습니다.",
    "#btnMakeBlogImage": "고른 스타일과 설명대로 AI가 블로그용 이미지를 만듭니다.",
    "[data-blog-design]": "네이버 블로그에 보낼 때의 글 꾸밈 모양입니다. 전송하기 전에 고르세요.",
    ".btn-blog-link": "네이버 블로그를 새 탭으로 엽니다. 글쓰기 화면을 열어 둔 뒤 [블로그글 전송하기]를 누르세요.",
    "#btnSendNaver": "제목과 본문을 열어 둔 네이버 블로그 글쓰기 화면에 채웁니다. 먼저 글쓰기 화면을 열어 두세요.",

    /* 3단계 — SNS (sns.js) */
    '[data-channel="blog"]': "네이버 블로그 글을 만들고 블로그 글쓰기 화면에 채웁니다.",
    '[data-channel="facebook"]': "페이스북 글 — 기사 소개 + 매물 링크. 사진은 정사각 1:1로 잘라 줍니다.",
    '[data-channel="instagram"]': "인스타그램 캡션 — 한 줄에 정보 하나. 사진은 세로 4:5로 잘라 줍니다 (사진 필수).",
    '[data-channel="threads"]': "스레드 글 — 대화하듯 짧게(글마다 500자), 이어 쓰기로 나눕니다.",
    "#btnMakeSns": "페이스북·인스타그램·스레드 글을 AI에 한 번에 요청합니다. 다 쓰면 [완성 글 가져오기]를 누르세요.",
    "#btnPullSns": "AI가 다 쓴 세 플랫폼 글을 이 탭으로 가져옵니다. AI 답변이 끝까지 나온 뒤에 누르세요.",
    "#btnReviseSns": "왼쪽 칸에 적은 고칠 점을 AI에 보내 지금 보는 플랫폼 글만 고칩니다.",
    "#btnPullSnsRevised": "수정 요청 후 글이 바뀌지 않았다면 눌러서 고친 글을 가져옵니다.",
    '.image-opts-toggle[data-target="snsImageOpts"]': "이 플랫폼 비율로 AI 이미지를 만듭니다. 실제 매물 사진이 있으면 대표(1번)로는 쓸 수 없습니다.",
    "#btnInsertSnsImage": "내 PC의 사진을 이 플랫폼 사진 끝에 넣습니다.",
    "#btnMakeSnsImage": "고른 스타일과 설명대로 AI가 이 플랫폼용 이미지를 만듭니다.",
    "#snsHomeLink": "이 플랫폼을 새 탭으로 엽니다. 새 게시물 화면에서 복사한 글을 붙여 넣고 내려받은 사진을 올리세요.",
    "#btnCopySns": "글(링크·출처·해시태그 포함)을 복사하고, 비율대로 자른 사진과 글(TXT)을 압축 파일 하나로 내려받습니다.",
    "#btnSnsCopyOnly": "글(링크·출처·해시태그 포함)만 복사합니다. 게시물 칸에 Ctrl+V로 붙여 넣으세요.",
    "#btnSnsZip": "사진(비율대로 자름)과 글(TXT)을 압축 파일 하나로 다운로드 폴더에 받습니다. 압축을 풀면 폴더 하나가 나옵니다.",

    /* 4단계 */
    "#btnMakeScript": "2단계에서 쓴 AI에 새 대화로 유튜브 대본을 요청합니다. 다 쓰면 [완성 대본 가져오기]를 누르세요.",
    "#btnPullScript": "AI가 다 쓴 대본을 이 탭으로 가져옵니다. AI 답변이 끝까지 나온 뒤에 누르세요.",
    "#btnYtPaste": "자동으로 못 가져왔을 때 — AI 답변을 직접 붙여 넣고 누르면 대본이 만들어집니다.",
    "#btnReviseScript": "왼쪽 칸에 적은 고칠 점을 AI에 보내 대본을 고칩니다.",
    "#btnPullScriptRevised": "수정 요청 후 대본이 바뀌지 않았다면 눌러서 고친 대본을 가져옵니다.",
    "#btnCopyNarration": "대본(내레이션) 전체를 복사합니다.",
    "#btnDownloadNarration": "대본을 메모장(.txt) 파일로 내려받습니다.",
  };

  const tip = document.createElement("div");
  tip.className = "gw-tip hidden";
  tip.setAttribute("role", "tooltip");
  document.body.appendChild(tip);

  let timer = 0;
  let current = null;

  function textFor(node) {
    /* 기본 title 은 말풍선으로 옮긴다 (브라우저 설명과 겹쳐 뜨지 않게) */
    if (node.title) { node.dataset.tip = node.title; node.removeAttribute("title"); }
    for (const sel in TIPS) if (node.matches(sel)) return TIPS[sel];
    return node.dataset.tip || "";
  }

  function show(node, text) {
    tip.textContent = text;
    tip.classList.remove("hidden", "below");
    const r = node.getBoundingClientRect();
    const w = tip.offsetWidth;
    const h = tip.offsetHeight;
    const left = Math.max(8, Math.min(window.innerWidth - w - 8, r.left + r.width / 2 - w / 2));
    let top = r.top - h - 8;
    if (top < 8) { top = r.bottom + 8; tip.classList.add("below"); }
    tip.style.left = `${Math.round(left)}px`;
    tip.style.top = `${Math.round(top)}px`;
  }

  function hide() {
    clearTimeout(timer);
    tip.classList.add("hidden");
    current = null;
  }

  document.addEventListener("pointerover", (e) => {
    if (e.pointerType === "touch" || !(e.target instanceof Element)) return;
    const node = e.target.closest("button, a, .chip, .choice, .blog-style-card");
    if (!node || node === current) return;
    const text = textFor(node);
    if (!text) { hide(); return; }
    current = node;
    clearTimeout(timer);
    timer = setTimeout(() => show(node, text), 250);
  });
  document.addEventListener("pointerout", (e) => {
    if (current && !(e.relatedTarget instanceof Node && current.contains(e.relatedTarget))) hide();
  });
  document.addEventListener("pointerdown", hide, true);
  document.addEventListener("scroll", hide, true);
})();
